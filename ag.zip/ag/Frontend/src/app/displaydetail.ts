export class displaydetail{
    constructor(
     supplierId:number,
     name:string,
     location:string,
     phoneNumber:number
 
    ){}}