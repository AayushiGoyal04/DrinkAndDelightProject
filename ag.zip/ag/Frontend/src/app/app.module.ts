import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SupplierDetailsComponent } from './supplier-details/supplier-details.component';
import { TrackProductsComponent } from './track-products/track-products.component';
import { ProductOrderService } from './product-order.service';
import {HttpClientModule} from '@angular/common/http';
import { SupplierService } from './supplier.service';

@NgModule({
  declarations: [
    AppComponent,
    SupplierDetailsComponent,
    TrackProductsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [ProductOrderService,SupplierService],
  bootstrap: [AppComponent]
})
export class AppModule { }





  