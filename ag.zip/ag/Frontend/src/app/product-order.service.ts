import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductOrderService {

  constructor(private http:HttpClient) { }
  public getProductById(id){
    
    return this.http.get("http://localhost:8300/api/v1/trackproducts/"+id);
    

}
}