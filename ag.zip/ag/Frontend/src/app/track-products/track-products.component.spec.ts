import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackProductsComponent } from './track-products.component';

describe('TrackProductsComponent', () => {
  let component: TrackProductsComponent;
  let fixture: ComponentFixture<TrackProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrackProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
