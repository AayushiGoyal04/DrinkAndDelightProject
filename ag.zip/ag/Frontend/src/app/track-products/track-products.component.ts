import { Component, OnInit, Output } from '@angular/core';
import { ProductOrderService } from '../product-order.service';
import { order } from '../order';

@Component({
  selector: 'app-track-products',
  templateUrl: './track-products.component.html',
  styleUrls: ['./track-products.component.css']
})
export class TrackProductsComponent implements OnInit {
  id:number;
  orders:any;

  constructor(private service:ProductOrderService) { }
  public DetailstById(){
    let output=this.service.getProductById(this.id)
    output.subscribe((data)=>{
      if(data==null){
        alert("Order Id is invalid");
        return false;
      }
      else{
        this.orders=data;
        return true;
      }});
    }
   

  ngOnInit(){
   let output=this.service.getProductById(this.id);
   output.subscribe()
  }

  }
