export class order{
    constructor(
    id:number,
    name:string,
    distributorId:number,
    quantityUnit:number,
    dateOfOrder:Date,
    dateOfDelivery:Date,
    pricePerUnit:number,
    totalPrice:number,
    deliveryStatus:string,
    warehouseId:number
    ){}}