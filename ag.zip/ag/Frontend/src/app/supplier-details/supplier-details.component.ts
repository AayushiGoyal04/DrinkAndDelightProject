import { Component, OnInit } from '@angular/core';
import { SupplierService } from '../supplier.service';
import { displaydetail } from '../displaydetail';
@Component({
  selector: 'app-supplier-details',
  templateUrl: './supplier-details.component.html',
  styleUrls: ['./supplier-details.component.css']
})
export class SupplierDetailsComponent implements OnInit {
  suppliers:any;
  supplier:displaydetail=new displaydetail(0,"","",0);
  constructor(private service:SupplierService) { }

  ngOnInit(){

    let resp=this.service.getDetails();
    resp.subscribe((data)=>this.suppliers=data);
 
  }

}

   
 

  