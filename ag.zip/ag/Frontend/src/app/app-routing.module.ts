import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SupplierDetailsComponent } from './supplier-details/supplier-details.component';
import { TrackProductsComponent } from './track-products/track-products.component';
import { AppComponent } from './app.component';


const routes: Routes = [
//{path:'' ,redirectTo:'view-supplier',pathMatch:'full'},
//{path:' ',component:AppComponent},
{path:'view-supplier',component:SupplierDetailsComponent},
{path:'product-order',component:TrackProductsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
