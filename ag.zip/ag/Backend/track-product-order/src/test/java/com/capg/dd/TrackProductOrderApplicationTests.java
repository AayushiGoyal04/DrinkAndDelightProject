package com.capg.dd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackProductOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
