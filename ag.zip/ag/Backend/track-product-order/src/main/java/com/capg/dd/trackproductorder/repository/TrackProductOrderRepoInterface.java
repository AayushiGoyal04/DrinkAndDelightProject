package com.capg.dd.trackproductorder.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capg.dd.trackproductorder.entity.TrackProductOrder;



@Repository
public interface TrackProductOrderRepoInterface extends JpaRepository<TrackProductOrder, Integer>{

	@Query(value="select * from track_product_order where id=?1",nativeQuery=true)
	
	List<TrackProductOrder> getTrackProductOrderDetails(int id);
	
}

