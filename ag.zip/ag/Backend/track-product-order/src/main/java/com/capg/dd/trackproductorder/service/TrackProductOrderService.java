package com.capg.dd.trackproductorder.service;

import java.util.List;

import com.capg.dd.trackproductorder.entity.TrackProductOrder;

public interface TrackProductOrderService {
	
	List<TrackProductOrder> getTrackProductOrderDetails(int id);
	
}
