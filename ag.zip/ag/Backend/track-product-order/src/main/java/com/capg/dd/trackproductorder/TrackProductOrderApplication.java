package com.capg.dd.trackproductorder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableDiscoveryClient
@EnableJpaRepositories("com.capg.dd.trackproductorder.repository")
public class TrackProductOrderApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrackProductOrderApplication.class, args);
	}

}
