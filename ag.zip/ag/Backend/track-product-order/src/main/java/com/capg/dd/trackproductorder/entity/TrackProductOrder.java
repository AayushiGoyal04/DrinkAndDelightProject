package com.capg.dd.trackproductorder.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

	@Entity
	@Table(name = "track_product_order")
	public class TrackProductOrder {

		private int id;
		private String name;
		private int distributorId;
		private int quantityUnit;
		private Date dateOfOrder;
		private Date dateOfDelivery;
		private int pricePerUnit;
		private int totalPrice;
		private String deliveryStatus;
		private int warehouseId;
	

		public TrackProductOrder() {

		}

		public TrackProductOrder(int id, String name, int distributorId, int quantityUnit, Date dateOfOrder, Date dateOfDelivery,
				int pricePerUnit, int totalPrice, String deliveryStatus, int warehouseId) {
			super();
			this.id = id;
			this.name = name;
			this.distributorId = distributorId;
			this.quantityUnit = quantityUnit;
			this.dateOfOrder = dateOfOrder;
			this.dateOfDelivery = dateOfDelivery;
			this.pricePerUnit = pricePerUnit;
			this.totalPrice = totalPrice;
			this.deliveryStatus = deliveryStatus;
			this.warehouseId = warehouseId;
		}

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}
		
		@Column(name = "name", length = 15)
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		@Column(name = "distributor_id")
		public int getDistributorId() {
			return distributorId;
		}

		public void setDistributorId(int distributorId) {
			this.distributorId = distributorId;
		}
		
		@Column(name = "quantity_unit")
		public int getQuantityUnit() {
			return quantityUnit;
		}

		public void setQuantityUnit(int quantityUnit) {
			this.quantityUnit = quantityUnit;
		}
		
		@Column(name = "date_of_order")
		public Date getDateOfOrder() {
			return dateOfOrder;
		}

		public void setDateOfOrder(Date dateOfOrder) {
			this.dateOfOrder = dateOfOrder;
		}
		
		@Column(name = "date_of_delivery")
		public Date getDateOfDelivery() {
			return dateOfDelivery;
		}

		public void setDateOfDelivery(Date dateOfDelivery) {
			this.dateOfDelivery = dateOfDelivery;
		}

		@Column(name = "price_per_unit")
		public int getPricePerUnit() {
			return pricePerUnit;
		}

		public void setPricePerUnit(int pricePerUnit) {
			this.pricePerUnit = pricePerUnit;
		}
		
		@Column(name = "total_price")
		public int getTotalPrice() {
			return totalPrice;
		}

		public void setTotalPrice(int totalPrice) {
			this.totalPrice = totalPrice;
		}


		@Column(name = "delivery_status")
		public String getDeliveryStatus() {
			return deliveryStatus;
		}

		public void setDeliveryStatus(String deliveryStatus) {
			this.deliveryStatus = deliveryStatus;
		}

		@Column(name = "warehouse_id")
		public int getWarehouseId() {
			return warehouseId;
		}

		public void setWarehouseId(int warehouseId) {
			this.warehouseId = warehouseId;
		}
		
		

		@Override
		public String toString() {
			return "TrackProductOrder [id=" + id + ", name=" + name + ", distributorId=" + distributorId
					+ ", quantityUnit=" + quantityUnit + ",dateOfOrder=" + dateOfOrder+",dateOfDelivery=" + dateOfDelivery
					+ ", pricePerUnit=" + pricePerUnit + ", totalPrice=" + totalPrice + ", deliveryStatus="
					+ deliveryStatus + ", warehouseId=" + warehouseId + "]";
		}

}
