package com.capg.dd.displaysupplierdetails.service;

import java.util.List;

import com.capg.dd.displaysupplierdetails.model.DisplaySupplierDetails;

public interface DisplaySupplierDetailsService {

	List<DisplaySupplierDetails> getSupplierDetails();

}
