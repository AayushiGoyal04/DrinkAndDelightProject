package com.capg.dd.displaysupplierdetails.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dd.displaysupplierdetails.model.DisplaySupplierDetails;
import com.capg.dd.displaysupplierdetails.repository.DisplaySupplierDetailsRepository;

@Service
public class DisplaySupplierDetailsServiceImpl implements DisplaySupplierDetailsService {
	
	@Autowired
	private DisplaySupplierDetailsRepository repository;

	@Override
	public List<DisplaySupplierDetails> getSupplierDetails() {
		return repository.findAll();
	}

}
