package com.capg.dd.displaysupplierdetails.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "suppliers")
public class DisplaySupplierDetails {

	private int supplierId;
	private String name;
	private String location;
	private int phoneNumber;

	public DisplaySupplierDetails() {

	}

	public DisplaySupplierDetails(int supplierId, String name, String location, int phoneNumber) {
		super();
		this.supplierId = supplierId;
		this.name = name;
		this.location = location;
		this.phoneNumber = phoneNumber;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}

	@Column(name = "name")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "location")
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Column(name = "phone_number")
	public int getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "DisplaySupplierDetails [supplierId=" + supplierId + ", name=" + name + ", location=" + location
				+ ", phoneNumber=" + phoneNumber + "]";
	}

}
