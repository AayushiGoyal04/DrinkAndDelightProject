package com.capg.dd.displaysupplierdetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.dd.displaysupplierdetails.model.DisplaySupplierDetails;
import com.capg.dd.displaysupplierdetails.service.DisplaySupplierDetailsService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class DisplaySupplierDetailsController {
	
	@Autowired
	private DisplaySupplierDetailsService service;
	
	@GetMapping("/getdetails")
	public List<DisplaySupplierDetails> getSupplierDetails(){
		
		return service.getSupplierDetails();
		
	}

}
