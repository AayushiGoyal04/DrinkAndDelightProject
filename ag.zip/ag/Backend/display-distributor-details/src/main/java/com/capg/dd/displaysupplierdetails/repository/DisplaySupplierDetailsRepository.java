package com.capg.dd.displaysupplierdetails.repository;

import org.springframework.stereotype.Repository;

import com.capg.dd.displaysupplierdetails.model.DisplaySupplierDetails;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface DisplaySupplierDetailsRepository extends JpaRepository<DisplaySupplierDetails,Integer> {

}
