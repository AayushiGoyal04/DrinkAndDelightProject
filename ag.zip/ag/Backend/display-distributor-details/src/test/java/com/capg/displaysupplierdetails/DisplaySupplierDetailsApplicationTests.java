package com.capg.displaysupplierdetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisplaySupplierDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
