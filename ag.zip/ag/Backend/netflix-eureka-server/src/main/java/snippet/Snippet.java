package snippet;

/*
 * public class Snippet { insert into movierating_tbl values (1003,3);
 * 
 * }
 * 
 */